vti_encoding:SR|utf8-nl
vti_author:SR|LAPTOP-7BE5NNNS\\shrad
vti_modifiedby:SR|LAPTOP-7BE5NNNS\\shrad
vti_timelastmodified:TR|23 May 2020 14:19:51 -0000
vti_timecreated:TR|23 May 2020 14:19:51 -0000
vti_cacheddtm:TX|23 May 2020 14:19:51 -0000
vti_filesize:IR|1979
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
