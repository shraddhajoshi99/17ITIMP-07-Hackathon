vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|23 May 2020 14:23:45 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|LAPTOP-7BE5NNNS\\shrad
vti_modifiedby:SR|LAPTOP-7BE5NNNS\\shrad
vti_timecreated:TR|23 May 2020 14:23:45 -0000
vti_cacheddtm:TX|23 May 2020 14:23:45 -0000
vti_filesize:IR|1061
vti_backlinkinfo:VX|
